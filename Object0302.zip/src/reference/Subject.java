package reference;

public class Subject {

	String SubjectName;
	int scorePoint;
	
	public static void main(String[] args) {
		

	}

}
