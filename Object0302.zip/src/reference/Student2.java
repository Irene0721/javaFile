package reference;

public class Student2 {

	int studentID;
	String studentName;
	int koreaScore;
	int mathScore;
	String koreaSubject;
	String mathSubject;
	
}
