package reference;

public class Student1 {

	int studentID;
	String studentName;
	int koreaScore;
	int mathScore;
	
}
