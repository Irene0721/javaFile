package object;

public class ReportEX {
		
		String name;
		String dept;
		int kor;
		int eng;
		int mat;
		
		public String getName() {
			return "�л� �̸� : "+name;
		}
		
		public String getDept() {
			return "�л� �а� : "+dept;
		}
		
		public String getKor() {
			return "�������� : "+kor;
		}
		
		public String getEng() {
			return "�������� : "+eng;
		}
		
		public String getMat() {
			return "�������� : "+mat;
		}

		public String Total() {
			int result=kor+eng+mat;
			return "�հ�: "+result;}
		
		public String Aver() {
			float result2=(float)(kor+eng+mat)/3.0F;
			return "���: "+result2; 
		}
		
		public String getComplete(){ 
			float result2=(float)(kor+eng+mat)/3.0F;
			String res;
		if (result2>=60) {
			res="�̼�";
		} else{ res="���̼�";}
		return "���: "+res;
		}
		
		public static void main(String[] args) {
		ReportEX Test=new ReportEX();
		
		Test.name="�ڸ���";
		Test.dept="���а�";
		Test.kor=80;
		Test.eng=70;
		Test.mat=60;
		
		System.out.println(Test.getName());
		System.out.println(Test.getDept());
		System.out.println(Test.getKor());
		System.out.println(Test.getEng());
		System.out.println(Test.getMat());
		System.out.println(Test.Total());
		System.out.println(Test.Aver());
		System.out.println(Test.getComplete());
		System.out.println();
		
		ReportEX Test2=new ReportEX();
		Test2.name="������";
		Test2.dept="ü���а�";
		Test2.kor=80;
		Test2.eng=40;
		Test2.mat=50;
		
		System.out.println(Test2.getName());
		System.out.println(Test2.getDept());
		System.out.println(Test2.getKor());
		System.out.println(Test2.getEng());
		System.out.println(Test2.getMat());
		System.out.println(Test2.Total());
		System.out.println(Test2.Aver());
		System.out.println(Test2.getComplete());
		
		}

}
