package object;

public class OderEX {
	
	String OderNum;
	String OderID;
	String OderDate;
	String OderName;
	String ItemNum;
	String Address;

	public String showOderNum() {
	return "�ֹ� ��ȣ: "+OderNum; 
	}
	
	public String showOderID() {
		return "�ֹ��� ���̵�: "+OderID;
	}
	
	public String showOderDate() {
		return "�ֹ� ��¥: "+OderDate;
	}
	
	public String showOderName() {
		return "�ֹ��� �̸�: "+OderName;
	}
	
	public String showItemNum() {
		return "�ֹ� ��ǰ ��ȣ: "+ItemNum;
	}
	
	public String showAddress() {
		return "��� �ּ�: "+Address;
	}
	
	public static void main(String[] args) {
		
		OderEX Q2=new OderEX();
		Q2.OderNum="201803120001";
		Q2.OderID="abc123";
		Q2.OderDate="2018�� 3�� 12��";
		Q2.OderName="ȫ���";
		Q2.ItemNum="PD0345-12";
		Q2.Address="����� �������� ���ǵ��� 20����";
		
		System.out.println(Q2.OderNum);
		System.out.println(Q2.OderID);
		System.out.println(Q2.OderDate);
		System.out.println(Q2.OderName);
		System.out.println(Q2.ItemNum);
		System.out.println(Q2.Address);
		
		System.out.println();
		
		System.out.println(Q2.showOderNum());
		System.out.println(Q2.showOderID());
		System.out.println(Q2.showOderDate());
		System.out.println(Q2.showOderName());
		System.out.println(Q2.showItemNum());
		System.out.println(Q2.showAddress());

	}

}
