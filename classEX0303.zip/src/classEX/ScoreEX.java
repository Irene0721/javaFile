package classEX;

public class ScoreEX {

	String ticketType;
	String manType;
	String dateType;
	int discount;
	int price;
	
	int period;
	String name;
	int age;
	
	
	public String getTicketType() {
		return "��������� ����: "+ticketType; 
	}
	
	public String getName() {
		return "�̸�: "+name;
	}
	
	public String getAge() {
		return "����: "+age+"��";
	}
	
	public String getManType() {
		String Man;
		
		if(age<19) {
			Man="û�ҳ�";
		}else { Man="�";}
		return "����: "+Man;
	}
	
	public int getDiscount() {
		float discount=0.0F;
		if(ticketType=="�Ϲ���" && age>=19 && period<=10) {
			discount=(float)0.45;
		}else if(ticketType=="�Ϲ���" && age>=19 && period>10 && period<=31) {
			discount=(float)0.5;
		}else if(ticketType=="�Ϲ���" && age<19 && period>1 && period<=31) {
			discount=(float)0.6;
		}else if(ticketType=="�Ⱓ������" && age>=19 && period<=20) {
			discount=(float)0.45;
		}else if(ticketType=="�Ⱓ������" && age>=19 && period>20 && period<=31) {
			discount=(float)0.5;
		}else if(ticketType=="�Ⱓ������" && age<19 && period>1 && period<=31) {
			discount=(float)0.6;
		}
		return (int)(100*discount);
	}
	
	public String getRate() {
		double rate=0.0;
		
		if(ticketType=="�Ϲ���") {
			if(getManType()=="�") {
				if(period<=10) { rate=0.45;
				}
				else if(period>10 && period<=31)
						{ rate=0.5; 
				}else { rate=0.0; }
			}else {rate=0.6;}
		}
		else if(ticketType=="�Ⱓ������") {
			if(getManType()=="�") {
				if(period<=20) { rate=0.45;
				}else if(period>20 && period<=31) { rate=0.5;
				}else { rate=0.0;} }
			else {rate=0.6;
				}
			}
	 return "������: "+(int)(100*rate);
	}
	
	
	public String getPrice() {
		int price=59800;
		
		int TotalPrice=(int)(price-(price*getDiscount()));
	return "����: "+TotalPrice+"��";
	}
	public static void main(String[] args) {
	
	ScoreEX score=new ScoreEX();
	
	score.period=10;
	score.name="������";
	score.age=22;
	score.ticketType="�Ⱓ������";
	
	
	System.out.println(score.getTicketType());
	System.out.println(score.getName());
	System.out.println(score.getAge());
	System.out.println(score.getManType());
	System.out.println("������: "+score.getDiscount()+"%");
	System.out.println(score.getPrice());
	System.out.println(score.getRate());
	System.out.println();
	
	ScoreEX score2=new ScoreEX();
	
	score2.period=25;
	score2.name="������";
	score2.age=18;
	score2.ticketType="�Ϲ���";

	
	System.out.println(score2.getTicketType());
	System.out.println(score2.getName());
	System.out.println(score2.getAge());
	System.out.println(score2.getManType());
	System.out.println("������: "+score2.getDiscount()+"%");
	System.out.println(score2.getPrice());
	
	}

}
